# Online-Food-Receipe
Online Food Recipe Website Created by using <b>Asp.Net MVC , SQL Server, HTML, CSS, BOOTSTRAP</b>.

<b>Home Page</b>
![Home Page1](https://user-images.githubusercontent.com/81013807/178677067-8b97e977-838a-4ac3-8718-8c5715ab63fd.png)

<b>Login Page</b>
![Login Page](https://user-images.githubusercontent.com/81013807/178677509-fd5eaa21-a5bb-4150-b140-f6f5fcdbda82.png)

<b>Registration Form</b>
![Registration Page](https://user-images.githubusercontent.com/81013807/178678349-f803540c-12f7-4987-96b5-59f678b4be0f.png)

<b>Forget Password</b>
![Forget Password](https://user-images.githubusercontent.com/81013807/178677628-f0806694-8984-4013-b6f1-31da4da5adaa.png)

<b>FirstMenu Page</b>
![FirstMenu Page](https://user-images.githubusercontent.com/81013807/178677751-72a76b13-f3a4-4565-bbe4-617fed0d300f.png)

<b>SecondMenu Page</b>
![SecondMenu Page](https://user-images.githubusercontent.com/81013807/178678463-35938064-b70d-4cc8-888c-ce84ca93a772.png)

<b>ThirdMenu Page</b>
![ThirdMenu Veg Page](https://user-images.githubusercontent.com/81013807/178678479-1f692c8f-ae6a-4026-bb83-a1f8a8f5e793.png)

<b>Recipe Information Page</b>
![Receipe Information Page](https://user-images.githubusercontent.com/81013807/178679314-bf9abf12-b300-4f25-ac4d-d8246b6ba672.png)

<b>New Adding Recipe Page</b>
![NewAddingReceipe Page](https://user-images.githubusercontent.com/81013807/178679715-47cd2ebf-dd89-4c9b-a58e-461266c98adc.png)

<b>BeverageMenu Page</b>
![BeverageMenu page](https://user-images.githubusercontent.com/81013807/178678372-d1d67dc9-760b-4c2a-8bf1-e41e7e020aa2.png)

<b>Modification Page</b>
![Modification Page](https://user-images.githubusercontent.com/81013807/178678430-b6ad3515-de8f-464d-8bd1-de968443bc87.png)

<b>Profile Page</b>
![Profile Page](https://user-images.githubusercontent.com/81013807/178677571-7b90d71a-6f89-4618-ac23-76448ed024ca.png)

<b>About Page</b>
![About Page](https://user-images.githubusercontent.com/81013807/178678525-78617486-80c3-47c9-bf92-a66a86823ec9.png)

<b>Feedback Form</b>
![Feedback ](https://user-images.githubusercontent.com/81013807/178678599-39308248-2891-4168-8106-68ad7e313655.png)

﻿namespace OnlineFoodReceipe.Models
{
    public class Feedback
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Msg { get; set; }
    }
}

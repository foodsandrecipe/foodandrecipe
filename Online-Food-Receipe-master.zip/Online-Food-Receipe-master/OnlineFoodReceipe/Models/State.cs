﻿namespace OnlineFoodReceipe.Models
{
    public class State
    {
        public string Sname { get; set; }
    }
}

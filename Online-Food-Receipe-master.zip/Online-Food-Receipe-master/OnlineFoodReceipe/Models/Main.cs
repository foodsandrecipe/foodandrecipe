﻿namespace OnlineFoodReceipe.Models
{
    public class Main
    {
        public int Id { get; set; }
        public int Rid { get; set; }
    }
}

﻿namespace OnlineFoodReceipe.Models
{
    public class Logged
    {
        public string Name { get; set; }
        public string Password { get; set; }
        public string Vnb { get; set; }
        public string Sname { get; set; }
    }
}
